#!/usr/bin/env python3
"""YouTube Data API v3 ile resumable video yuklemesi (Parallax Publisher OAuth uygulamasi).

  secrets run youtube -- python3 youtube_yukle.py <kanal> <video.mp4> --baslik "..." [--aciklama "..."]
      [--gorunurluk private|unlisted|public] [--sil] [--dry]

<kanal>: benburakcem ya da ailabturkey. Anahtarlar ortamdan gelir (kasa servisi `youtube`):
YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REFRESH_TOKEN_BENBURAKCEM, YOUTUBE_REFRESH_TOKEN_AILABTURKEY.

Akis: (1) refresh_token ile erisim anahtari alinir, (2) channels.list mine=true ile anahtarin kanali okunur ve
beklenen kanal kimligiyle eslesmezse yukleme yapilmaz, (3) videos.insert resumable oturum acilir ve dosya
gonderilir, (4) videos.list ile gorunurluk geri okunur, (5) --sil verilirse videos.delete.
Varsayilan gorunurluk private. public yalniz kurucu yayin onayiyla verilir (marka hesaba yayin kurali).
Uygulama dogrulanmamisken API ile yuklenen videolar private'a kilitlenebilir.
Anahtar degerleri hicbir zaman yazdirilmaz."""
import argparse, json, os, sys, urllib.error, urllib.parse, urllib.request

KANALLAR = {
    "benburakcem": ("UCtbcOsx-tnak-Fz02yQZIOA", "YOUTUBE_REFRESH_TOKEN_BENBURAKCEM"),
    "ailabturkey": ("UCc619CXJVT-os8FwHjE0tsQ", "YOUTUBE_REFRESH_TOKEN_AILABTURKEY"),
}
API = "https://www.googleapis.com/youtube/v3"


def istek(url, veri=None, baslik=None, yontem=None):
    req = urllib.request.Request(url, data=veri, headers=baslik or {}, method=yontem)
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            govde = r.read()
            return r.status, dict(r.headers), (json.loads(govde) if govde else {})
    except urllib.error.HTTPError as e:
        govde = e.read().decode("utf-8", "replace")
        raise SystemExit("HTTP %s %s: %s" % (e.code, url.split("?")[0], govde[:600]))


def erisim_anahtari(refresh_env):
    for ad in ("YOUTUBE_CLIENT_ID", "YOUTUBE_CLIENT_SECRET", refresh_env):
        if not os.environ.get(ad):
            raise SystemExit("ortamda yok: %s (secrets run youtube -- ile calistir)" % ad)
    veri = urllib.parse.urlencode({
        "client_id": os.environ["YOUTUBE_CLIENT_ID"],
        "client_secret": os.environ["YOUTUBE_CLIENT_SECRET"],
        "refresh_token": os.environ[refresh_env],
        "grant_type": "refresh_token",
    }).encode()
    _, _, j = istek("https://oauth2.googleapis.com/token", veri,
                    {"Content-Type": "application/x-www-form-urlencoded"})
    print("token yenilendi, kapsam:", j.get("scope"))
    return j["access_token"]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("kanal", choices=sorted(KANALLAR))
    p.add_argument("video")
    p.add_argument("--baslik", required=True)
    p.add_argument("--aciklama", default="")
    p.add_argument("--gorunurluk", default="private", choices=["private", "unlisted", "public"])
    p.add_argument("--sil", action="store_true", help="yuklemeden sonra videoyu sil (test)")
    p.add_argument("--dry", action="store_true", help="yalniz token ve kanal dogrulamasi")
    a = p.parse_args()

    beklenen, refresh_env = KANALLAR[a.kanal]
    tok = erisim_anahtari(refresh_env)
    yetki = {"Authorization": "Bearer " + tok}

    _, _, ch = istek(API + "/channels?part=id,snippet&mine=true", baslik=yetki)
    kimlikler = [(i["id"], i["snippet"].get("customUrl") or i["snippet"].get("title")) for i in ch.get("items", [])]
    print("anahtarin kanali:", kimlikler)
    if beklenen not in [k for k, _ in kimlikler]:
        raise SystemExit("KANAL ESLESMEDI, yukleme yapilmadi: beklenen %s" % beklenen)
    if a.dry:
        print("dry: kanal dogrulandi, yukleme yok"); return

    boyut = os.path.getsize(a.video)
    meta = json.dumps({
        "snippet": {"title": a.baslik, "description": a.aciklama, "categoryId": "28"},
        "status": {"privacyStatus": a.gorunurluk, "selfDeclaredMadeForKids": False},
    }).encode()
    _, h, _ = istek(API.replace("/youtube/v3", "/upload/youtube/v3") + "/videos?uploadType=resumable&part=snippet,status",
                    meta, dict(yetki, **{"Content-Type": "application/json; charset=UTF-8",
                                         "X-Upload-Content-Type": "video/*",
                                         "X-Upload-Content-Length": str(boyut)}), "POST")
    oturum = h.get("Location") or h.get("location")
    if not oturum:
        raise SystemExit("resumable oturum adresi gelmedi")
    with open(a.video, "rb") as f:
        _, _, v = istek(oturum, f.read(), dict(yetki, **{"Content-Type": "video/*", "Content-Length": str(boyut)}), "PUT")
    vid = v["id"]
    print("yuklendi: id", vid, "istenen gorunurluk", a.gorunurluk)

    _, _, l = istek(API + "/videos?part=status,snippet&id=" + vid, baslik=yetki)
    st = l["items"][0]["status"] if l.get("items") else {}
    print("geri okunan: privacyStatus", st.get("privacyStatus"), "uploadStatus", st.get("uploadStatus"),
          "kanal", l["items"][0]["snippet"].get("channelId") if l.get("items") else None)

    if a.sil:
        kod, _, _ = istek(API + "/videos?id=" + vid, baslik=yetki, yontem="DELETE")
        print("silme: HTTP", kod)


if __name__ == "__main__":
    main()
